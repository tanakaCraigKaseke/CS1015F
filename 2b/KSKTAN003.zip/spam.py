# spam.py
# Program to generate a personalized spam message
# Author: [Your Name]
# Date: [Current Date]

first_name = input("Enter first name:\n")
last_name = input("Enter last name:\n")
money = float(input("Enter sum of money in USD:\n"))
country = input("Enter country name:\n")

money30 = money * 0.3

# Ensure `money30` is formatted with exactly one decimal place
money30_str = f"{money30:.1f}"

print(f"\nDearest {first_name}\n"
      f"It is with a heavy heart that I inform you of the death of my father,\n"
      f"General Fayk {last_name}, your long lost relative from Mapsfostol.\n"
      f"My father left the sum of {int(money)}USD for us, your distant cousins.\n"
      f"Unfortunately, we cannot access the money as it is in a bank in {country}.\n"
      f"I desperately need your assistance to access this money.\n"
      f"I will even pay you generously, 30% of the amount - {money30_str}USD,\n"
      f"for your help.  Please get in touch with me at this email address asap.\n"
      f"Yours sincerely\nFrank {last_name}")